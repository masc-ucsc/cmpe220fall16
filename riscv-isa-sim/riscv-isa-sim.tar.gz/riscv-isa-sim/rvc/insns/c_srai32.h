require_rvc;
require_xpr64;
CRDS = sreg_t(CRDS) >> (32+CIMM5U);
