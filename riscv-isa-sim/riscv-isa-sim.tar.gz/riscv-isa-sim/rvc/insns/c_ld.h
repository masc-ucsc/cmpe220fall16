require_rvc;
require_xpr64;
CRDS = mmu.load_int64(CRS1S+CIMM5*8);
