require_rvc;
CRD = CRS1 + CRS2;
