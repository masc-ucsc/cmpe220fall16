require_rvc;
require_fp;
FCRDS = mmu.load_int32(CRS1S+CIMM5*4);
