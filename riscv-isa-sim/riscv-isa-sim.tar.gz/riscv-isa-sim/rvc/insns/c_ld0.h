require_rvc;
require_xpr64;
CRD = mmu.load_int64(CRS1);
