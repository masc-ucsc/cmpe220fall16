require_rvc;
CRDS = CRS1S & CRS2BS;
