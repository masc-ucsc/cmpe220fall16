require_rvc;
require_xpr64;
CRDS = sext32(CRDS << CIMM5U);
