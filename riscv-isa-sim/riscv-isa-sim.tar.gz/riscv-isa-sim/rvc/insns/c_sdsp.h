require_rvc;
require_xpr64;
mmu.store_uint64(XPR[30]+CIMM6*8, CRS2);
