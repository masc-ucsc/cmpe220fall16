require_rvc;
mmu.store_uint32(CRS1S+CIMM5*4, CRS2S);
