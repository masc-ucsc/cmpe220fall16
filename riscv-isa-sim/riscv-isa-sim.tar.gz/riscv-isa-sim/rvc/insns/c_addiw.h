require_rvc;
require_xpr64;
CRD = sext32(CRS2 + CIMM6);
