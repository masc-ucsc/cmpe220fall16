require_extension('D');
require_fp;
WRITE_FRD(FRS1 ^ (FRS2 & INT64_MIN));
